#include <zephyr/kernel.h>
#include <zephyr/sys/printk.h>
#include <zephyr/device.h>
#include <zephyr/sys/cbprintf.h>
#include <zephyr/devicetree.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <zephyr/drivers/spi.h>
#include <zephyr/drivers/gpio.h>
#include <math.h>
#include <zephyr/sys/util.h>
#include <ti/driverlib/dl_mathacl.h>
#include "randomValues.h"
#include <ti/devices/msp/msp.h>
#include <ti/driverlib/dl_common.h>

#define ZEPHYR_USER_NODE DT_PATH(zephyr_user)
#define SPI_1_NODE	DT_NODELABEL(spi1)
#define LED0_NODE DT_NODELABEL(led0)

#define SAMP_BITS 12
#define NUM_BITS 16
#define NUM_SAMPLES pow(2,SAMP_BITS)
#define FULL_SCALE 5
#define MAX_NUM pow(2,NUM_BITS)
#define SPI_PACKET_SIZE 4
#define SAC_MASK 0x000000000000FFFF

#define STACKSIZE 1024
#define PRIORITY 7
#define SLEEPTIME 500

extern const uint16_t gRandomLUT[];

bool dataReady;
bool gpio_state = true;

int sampleCounter;
int transactionFlag = 0;

float radicand = 0;
float SN = 0;

uint8_t rxdata[2];
uint8_t rxBuffer[64];
uint8_t spiData[SPI_PACKET_SIZE] = {0x0,0x0,0x0,0x0};

uint16_t adcRX, cSample;

uint32_t rxBufferPtr 	= 0;
uint32_t SN_Q30 		= 0;
uint32_t sqrtRes_Q16 	= 0;
uint32_t UN 			= 0;
uint32_t SFACTOR 		= 0;
uint32_t count 			= 0;

int32_t vRMS,vMIN, vMAX, VDC, pk_pk;
int32_t dataOutput[5];

//int sampleCounter;
int64_t sacSum, sumSAMP, sacRes1, sacRes2;

const struct gpio_dt_spec reset = GPIO_DT_SPEC_GET(ZEPHYR_USER_NODE, reset_gpios);
const struct gpio_dt_spec start = GPIO_DT_SPEC_GET(ZEPHYR_USER_NODE, start_gpios);
const struct gpio_dt_spec drdy = GPIO_DT_SPEC_GET(ZEPHYR_USER_NODE, drdy_gpios);
const struct gpio_dt_spec en = GPIO_DT_SPEC_GET(ZEPHYR_USER_NODE, en_gpios);
const struct gpio_dt_spec done = GPIO_DT_SPEC_GET(ZEPHYR_USER_NODE, done_gpios);
const struct gpio_dt_spec led = GPIO_DT_SPEC_GET(LED0_NODE, gpios);
const struct device *const dev = DEVICE_DT_GET(SPI_1_NODE);

struct k_sem spiSem;
struct k_sem drdySem;
struct k_sem rxReadySem;
struct k_sem displaySem;

static struct k_thread thread_disp_data;
static struct k_thread thread_tim_data;
static struct k_thread thread_spi_data;
static struct gpio_callback drdy_cb_data;

struct spi_cs_control cs_ctrl = (struct spi_cs_control){
	.gpio = GPIO_DT_SPEC_GET(SPI_1_NODE, cs_gpios),
	.delay = 0u,
};

const DL_MathACL_operationConfig gMACConfig = {
	.opType = MATHACL_CTL_FUNC_MAC,
	.opSign = DL_MATHACL_OPSIGN_SIGNED,
	.iterations = 1,
	.scaleFactor = 0,
	.qType = DL_MATHACL_Q_TYPE_Q16
};

DL_MathACL_operationConfig gSQRTConfig = {
	.opType      = DL_MATHACL_OP_TYPE_SQRT,
	.opSign      = DL_MATHACL_OPSIGN_UNSIGNED,
	.iterations  = 5,
	.scaleFactor = 0,
	.qType       = DL_MATHACL_Q_TYPE_Q30
};

const DL_MathACL_operationConfig gMpyConfig = {
	.opType = MATHACL_CTL_FUNC_MPY64,
	.opSign = MATHACL_CTL_OPTYPE_SIGNED,
	.iterations = 1,
	.scaleFactor = 0,
	.qType = MATHACL_CTL_QVAL_Q16
};

/* define semaphores */
K_SEM_DEFINE(thread_tmr_sem, 1, 1);		/* starts off "available" */
K_SEM_DEFINE(thread_spi_sem, 0, 1);		/* starts off "not available" */
K_SEM_DEFINE(thread_disp_sem, 0, 1);	/* starts off "not available" */

K_THREAD_STACK_DEFINE(thread_tim_stack_area, STACKSIZE);
K_THREAD_STACK_DEFINE(thread_spi_stack_area, STACKSIZE);
K_THREAD_STACK_DEFINE(thread_disp_stack_area, STACKSIZE);

/* thread_a is a dynamic thread that is spawned in main */
void thread_tim_entry_point(void *dummy1, void *dummy2, void *dummy3){

	int i = 0;

	while(1){
		for(i = 0; i<NUM_SAMPLES;i++){
			gpio_state = !gpio_state; 			// toggle state for GPIO
			gpio_pin_set_dt(&en,gpio_state);	// set the enable pin to new GPIO_state
			k_sem_give(&spiSem);				// give semaphore to the spi thread
			printf("TIMER THREAD: Semaphore sent to SPI thread");
			k_usleep(gRandomLUT[i]); 			// go to sleep for time in LUT[current position]
		}
	}
}

/* thread_a is a dynamic thread that is spawned in main */
void thread_spi_entry_point(void *dummy1, void *dummy2, void *dummy3){

	int i = 0;

	sampleCounter = NUM_SAMPLES; 	// set initial sample window count
//	dataReady = false;

    // Do we need to add a conditional statement to only run this when the GPIO in TIM thread is low?
	while (1) {
		k_sem_take(&thread_spi_sem, K_FOREVER);
		printf("SPI THREAD: SPI Semaphore recieved in SPI thread\n");
		setSTART(true); // Sem has arrived, start the ADC for the next part
		sumSAMP = 0;

		for(i = 0;i<NUM_SAMPLES;i++){
			k_sem_take(&drdySem, K_FOREVER); // wait here until the drdy SEM has been handed off
			printf("SPI THREAD: SPI DRDY SEM recieved in SPI thread\n");
			SPI_TRX(dev, &cs_ctrl, spiData); // drdy sem arrived from callback, we are ready to pull a sample from ADC

			if(i>=0){
				cSample = (uint16_t)((rxdata[0] << 8) | (rxdata[1])); //--------> need to add the callback back in for the spi RX

				DL_MathACL_configOperation(MATHACL, &gMACConfig, cSample, cSample);
				DL_MathACL_waitForOperation(MATHACL);

				sumSAMP = sumSAMP + cSample; 		// add value to total sum for this window
				//sacSum = sacSum + (cSample * cSample);

				if(cSample > vMAX){          // Set min and max values based on samples we have already taken
					vMAX = cSample;
				} else if(cSample < vMIN){
					vMIN = cSample;
				}
			} else{ // do this for the last sample we take in the window
				cSample = (uint16_t)((rxdata[0] << 8) | (rxdata[1]));
				DL_MathACL_configOperation(MATHACL, &gMACConfig, cSample, cSample);
				DL_MathACL_waitForOperation(MATHACL);
				sumSAMP = sumSAMP + cSample; 		// add value to total sum for this window

				if(cSample > vMAX){          // Set min and max values based on samples we have already taken
					vMAX = cSample;
				} else if(cSample < vMIN){
					vMIN = cSample;
				}
			}
		}
		printf("SPI THREAD: Sample period complete! Sending for calculations\n");
		calculateResult(); // calculate results to be sent to display
		k_sem_give(&displaySem);
		printf("SPI THREAD: Sending Semaphore to display thread\n");
	}
	//setSTART(false);
}

/* thread_a is a dynamic thread that is spawned in main */
void thread_disp_entry_point(void *dummy1, void *dummy2, void *dummy3){
	int32_t dRMS,dMIN,dMAX,dVDC, dpk_pk;

    while(1){
	    k_sem_take(&displaySem, K_FOREVER);
    	printf("DISPLAY THREAD: Semaphore Recieved From SPI THREAD\n");
	    dMIN 	= dataOutput[0];
	    dMAX 	= dataOutput[1];
	    dpk_pk 	= dataOutput[2];
	    dVDC 	= dataOutput[3];
	    dRMS 	= dataOutput[4];
	    //------------------send this to be displayed on LCD------------>
    }
}

void adcSetup(){
	uint8_t *tmpBuffer;

	setRESET (true);
	setSTART (false);

	printf("Setting up ADC...\n");
	tmpBuffer = (uint8_t [4]){0x8, 0x5,0x0,0x3};
	SPI_TRX(dev, &cs_ctrl, tmpBuffer);
	k_sleep(K_MSEC(100));

	tmpBuffer = (uint8_t [4]){0x8, 0x6,0x0,0x8};
	SPI_TRX(dev, &cs_ctrl, tmpBuffer);
	k_sleep(K_MSEC(100));

	tmpBuffer = (uint8_t [4]){0x8, 0x7,0x0,0xB};
	SPI_TRX(dev, &cs_ctrl, tmpBuffer);
	k_sleep(K_MSEC(100));

	tmpBuffer = (uint8_t [4]){0x8, 0x8,0x0,0x8};
	SPI_TRX(dev, &cs_ctrl, tmpBuffer);
	k_sleep(K_MSEC(100));

	printf("Done Setting up ADC...\n");
}

void setSTART(bool state){
    uint8_t value = (uint8_t)(state ? 1 : 0);
    gpio_pin_set_dt(&start, value);
}

void setRESET(bool state) {
    uint8_t value = (uint8_t)(state ? 1 : 0);
    gpio_pin_set_dt(&reset, value);
}

void toggleRESET(void) {
	setRESET(false);
	k_sleep(K_MSEC(3));
	setRESET(true);
	k_sleep(K_MSEC(3));
}

void resetVars(){
	vMIN 	= MAX_NUM + 1;
	vMAX 	= -MAX_NUM - 1;
	sumSAMP = 0;
	sacSum  = 0;
	pk_pk 	= 0;
	sampleCounter = NUM_SAMPLES;
	vRMS = 0;
}

void spi_callback(const struct device * dev, int status, void * userdata){
	for(int i = 0; i < 2; i++){
		rxBuffer[rxBufferPtr] = rxdata[i];
		rxBufferPtr++;
	}
	printf("SPI Callback set Transaction Flag!\n");
	transactionFlag = 1;
}

void SPI_TRX(const struct device *dev, struct spi_cs_control *cs, uint8_t packet[]){

	struct spi_config config;

	config.frequency = 1000000;
	config.operation = SPI_OP_MODE_MASTER | SPI_WORD_SET(8);
	config.slave = 0;
	config.cs = *cs;

	enum { datacount = 4 };
	uint8_t buff[datacount] = { packet[0], packet[1], packet[2], packet[3]};
	uint8_t rxdata[2];

	struct spi_buf tx_buf[1] = {
		{.buf = buff, .len = datacount},
	};
	struct spi_buf rx_buf[1] = {
		{.buf = rxdata, .len = 2},
	};

	struct spi_buf_set tx_set = { .buffers = tx_buf, .count = 1 };
	struct spi_buf_set rx_set = { .buffers = rx_buf, .count = 1 };

	int ret = spi_transceive_cb(dev, &config, &tx_set, &rx_set, spi_callback, NULL);

	printf(" tx (i)  : %x %x %x %x \n", buff[0], buff[1], buff[2], buff[3]);
	printf(" rx (i)  : %x %x \n", rxdata[0], rxdata[1]);

	while(transactionFlag == 0){
		k_usleep(20);
	}
}

void drdyEdge(const struct device *dev, struct gpio_callback *cb, uint32_t pins){
	printf("Drdy Edge GPIO Call\n");
	k_sem_give(&drdySem);
	printf("DRDY Callback sending Semaphore to SPI thread\n");
	//dataReady = true;
	//SPI_TRX(dev, &cs_ctrl, spiData);  // get data from the ADC and send to buffer
}

int main(void){

	int ret;

	gpio_pin_configure_dt(&reset, GPIO_OUTPUT_INACTIVE);
	gpio_pin_configure_dt(&start, GPIO_ACTIVE_HIGH);
	gpio_pin_configure_dt(&drdy,  GPIO_ACTIVE_HIGH);
	gpio_pin_configure_dt(&en,    GPIO_ACTIVE_HIGH);
	gpio_pin_configure_dt(&done,  GPIO_ACTIVE_HIGH);

	k_sem_init(&spiSem, 1, 0);
	k_sem_init(&drdySem, 1, 0);
	k_sem_init(&displaySem, 1, 0);
	k_sem_init(&rxReadySem, 1, 0);

	if (!device_is_ready(dev)) {
		printk("%s: device not ready.\n", dev->name);
		return 0;
	}

	ret = gpio_pin_configure_dt(&drdy, GPIO_INPUT);
	if(ret !=0){
		printk("Error configuring button pin.\n");
		return 0;
	}

	ret = gpio_pin_interrupt_configure_dt(&drdy, GPIO_INT_EDGE_TO_ACTIVE);
	if(ret !=0){printk("Button pressed at %" PRIu32 "\n", k_cycle_get_32());
			printk("Error configuring button pin.\n");
			return 0;
	}

	k_thread_create(&thread_tim_data, thread_tim_stack_area,
			K_THREAD_STACK_SIZEOF(thread_tim_stack_area),
			thread_tim_entry_point, NULL, NULL, NULL,
			PRIORITY, 0, K_FOREVER);
	k_thread_name_set(&thread_tim_data, "Timer Thread");

	k_thread_create(&thread_spi_data, thread_spi_stack_area,
			K_THREAD_STACK_SIZEOF(thread_spi_stack_area),
			thread_spi_entry_point, NULL, NULL, NULL,
			PRIORITY, 1, K_FOREVER);
	k_thread_name_set(&thread_spi_data, "SPI Thread");

	k_thread_create(&thread_disp_data, thread_disp_stack_area,
			K_THREAD_STACK_SIZEOF(thread_disp_stack_area),
			thread_disp_entry_point, NULL, NULL, NULL,
			PRIORITY, 2, K_FOREVER);
	k_thread_name_set(&thread_disp_data, "Display Thread");



	gpio_init_callback(&drdy_cb_data, drdyEdge, BIT(drdy.pin));
	gpio_add_callback(drdy.port, &drdy_cb_data);

	adcSetup();                        // 1 time setup of the ADC based on requirements

    DL_MathACL_enablePower(MATHACL);   // Power on the MATHACL
    DL_MathACL_clearResults(MATHACL);  // clear the results from the MATHACL if applicable
    DL_MathACL_waitForOperation(MATHACL);

	k_thread_start(&thread_tim_data);
	k_thread_start(&thread_spi_data);
	k_thread_start(&thread_disp_data);

	return 0;
}

void calculateResult(){

	int32_t rtDiv = 0;

	/* MATHACL has been multiplying and accumulating in thread, pull data into workspace */
	sacRes1 = DL_MathACL_getResultOne(MATHACL);
	sacRes2 = DL_MathACL_getResultTwo(MATHACL);
	sacSum = ((sacRes1) << 16 ) | (sacRes2);

	DL_MathACL_clearResults(MATHACL);
	DL_MathACL_waitForOperation(MATHACL);

	rtDiv = (sacSum >> SAMP_BITS);
	UN = floor(rtDiv);
   	SFACTOR = 0;
    count = 2;
    SN = 0;

    do {
        SFACTOR++;
        count <<= 1;
    } while(count < UN);

    SN = rtDiv / (count >> 1);
    SN_Q30 = (uint32_t) (SN * (1 << 30));
    gSQRTConfig.scaleFactor = SFACTOR;

    DL_MathACL_startSqrtOperation(MATHACL, &gSQRTConfig, SN_Q30);
    DL_MathACL_waitForOperation(MATHACL);
    sqrtRes_Q16 = DL_MathACL_getResultOne(MATHACL);
	DL_MathACL_waitForOperation(MATHACL);

	vRMS = sqrtRes_Q16 * FULL_SCALE;
	DL_MathACL_clearResults(MATHACL);

	VDC   = (sumSAMP >>SAMP_BITS) * FULL_SCALE;
	vMIN  = vMIN * FULL_SCALE;
	vMAX  = vMAX * FULL_SCALE;
	pk_pk = vMAX - vMIN;

	/* Done with the math calculations, reset all the variables*/
	resetVars();

	dataOutput[0] =  vMIN;		// minimum voltage converted from ADC value to voltage
	dataOutput[1] =  vMAX; 		// maximum voltage converted from ADC value to voltage
	dataOutput[2] =  pk_pk;		// Pk-pk voltage from ADC value
	dataOutput[3] =  VDC;		// DC voltage form ADC value
	dataOutput[4] =  vRMS;    	// VRMS form ADC values * sqrt(2)

//	k_sleep(K_MSEC(3000)); // just using for debug to keep output visible for 10 seconds
//	gpio_pin_set_dt(&done, 0); // done with this windo of data, toggle LED

}

