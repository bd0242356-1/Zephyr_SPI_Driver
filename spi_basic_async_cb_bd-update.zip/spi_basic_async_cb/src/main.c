/*
 * Copyright (c) 2021 Marc Reilly, Creative Product Design
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/devicetree.h>
#include <stdio.h>
#include <string.h>
#include <zephyr/drivers/spi.h>
#include <stdlib.h>
#include <zephyr/drivers/gpio.h>
#include <math.h>
#include <zephyr/sys/util.h>
#include <ti/driverlib/dl_mathacl.h>
#include "randomValues.h"
#include <ti/driverlib/dl_timera.h>
#include <ti/driverlib/dl_timerg.h>
#include <ti/devices/msp/msp.h>
#include <ti/driverlib/dl_common.h>


#define ZEPHYR_USER_NODE DT_PATH(zephyr_user)
#define SPI_1_NODE	DT_NODELABEL(spi1)
#define LED0_NODE DT_NODELABEL(led0)
#define SAMP_BITS 12
#define NUM_BITS 16
#define NUM_SAMPLES 32//pow(2,SAMP_BITS)
#define FULL_SCALE 5
#define MAX_NUM pow(2,NUM_BITS)
#define SAC_MASK 0x000000000000FFFF

uint8_t buff[3] = { 0x11, 0x22, 0x33};
uint8_t rxdata[3];
uint8_t rxBuffer[64];

uint16_t adcRX, cSample;

uint32_t rxBufferPtr = 0;
uint32_t UN = 0;
uint32_t SFACTOR = 0;
uint32_t count = 0;
uint32_t SN_Q30 = 0;
uint32_t sqrtRes_Q16 = 0;

int32_t vMIN, vMAX, VDC, pk_pk;
int32_t vRMS;
int32_t dataOutput[5];

int64_t sacSum, sumSAMP, sacRes1, sacRes2;

int transactionFlag = 0;
int sampleCounter;
int sqrtRes1, sqrtRes2, combVal;

float radicand = 0;
float SN = 0;
float SQRTRes;

bool  dataReady;

////////////////////////////////////////////////////////////////////////////////////////////
//    MATHACL Configurations

const DL_MathACL_operationConfig gSACConfig = {
	.opType = MATHACL_CTL_FUNC_SAC,
	.opSign = DL_MATHACL_OPSIGN_SIGNED,
	.iterations = 1,
	.scaleFactor = 0,
	.qType = DL_MATHACL_Q_TYPE_Q16
};

DL_MathACL_operationConfig gSQRTConfig = {
	.opType      = DL_MATHACL_OP_TYPE_SQRT,
	.opSign      = DL_MATHACL_OPSIGN_UNSIGNED,
	.iterations  = 5,
	.scaleFactor = 0,
	.qType       = DL_MATHACL_Q_TYPE_Q30
};

////////////////////////////////////////////////////////////////////////////////////////////

const struct gpio_dt_spec reset = GPIO_DT_SPEC_GET(ZEPHYR_USER_NODE, reset_gpios);
const struct gpio_dt_spec start = GPIO_DT_SPEC_GET(ZEPHYR_USER_NODE, start_gpios);
const struct gpio_dt_spec drdy = GPIO_DT_SPEC_GET(ZEPHYR_USER_NODE, drdy_gpios);
const struct gpio_dt_spec en = GPIO_DT_SPEC_GET(ZEPHYR_USER_NODE, en_gpios);
const struct gpio_dt_spec done = GPIO_DT_SPEC_GET(ZEPHYR_USER_NODE, done_gpios);
static struct gpio_callback drdy_cb_data;
const struct device *const dev = DEVICE_DT_GET(SPI_1_NODE);

struct spi_cs_control cs_ctrl = (struct spi_cs_control){
	.gpio = GPIO_DT_SPEC_GET(SPI_1_NODE, cs_gpios),
	.delay = 0u,
};

void setSTART(const bool state){
	uint8_t value = (uint8_t)(state ? 1 : 0);
	gpio_pin_set_dt(&start, value);
}

void setRESET(const bool state) {
	printf("ADC Reset Request\n");
	uint8_t value = (uint8_t)(state ? 1 : 0);
	gpio_pin_set_dt(&reset, value);
}

void adcSetup(void){
	uint8_t *tmpBuffer;
	setRESET (true);
	setSTART (false);

	printf("Setting up ADC...\n");
	tmpBuffer = (uint8_t [4]){0x8, 0x5,0x0,0x3};
	test_8bit_xfer(dev, &cs_ctrl, tmpBuffer);
	k_sleep(K_MSEC(1000));

	tmpBuffer = (uint8_t [4]){0x8, 0x6,0x0,0x8};
	test_8bit_xfer(dev, &cs_ctrl, tmpBuffer);
	k_sleep(K_MSEC(1000));

	tmpBuffer = (uint8_t [4]){0x8, 0x7,0x0,0xB};
	test_8bit_xfer(dev, &cs_ctrl, tmpBuffer);
	k_sleep(K_MSEC(1000));

	tmpBuffer = (uint8_t [4]){0x8, 0x8,0x0,0x8};
	test_8bit_xfer(dev, &cs_ctrl, tmpBuffer);
	k_sleep(K_MSEC(1000));

	printf("Done Setting up ADC...\n");
}

void resetVars(void){
	//printf("Resetting Variable Values for Next Window\n");
	vMIN 	= MAX_NUM + 1;
	vMAX 	= -MAX_NUM - 1;
	sumSAMP = 0;
	sacSum  = 0;
	pk_pk 	= 0;
	sampleCounter = NUM_SAMPLES;
	vRMS = 0;

}
void spi_callback(const struct device * dev, int status, void * userdata){
	for(int i = 0; i < 3; i++){
		rxBuffer[rxBufferPtr] = rxdata[i];
		rxBufferPtr++;
	}
	transactionFlag = 1;
}

void calculateResult(void){
	//	vRMS  = sqrt(sacSum >> SAMP_BITS) * FULL_SCALE;
	VDC   = (sumSAMP >>SAMP_BITS) * FULL_SCALE;
	vMIN  = vMIN * FULL_SCALE;
	vMAX  = vMAX * FULL_SCALE;
	pk_pk = vMAX - vMIN;

	DL_MathACL_waitForOperation(MATHACL);
	sacRes1 = DL_MathACL_getResultOne(MATHACL);
	sacRes2 = DL_MathACL_getResultTwo(MATHACL);
	sacSum = ((sacRes2) <<16) | ((sacRes1) & SAC_MASK);

	//	printf("Sample 1 Result: %lld\n", sacRes1);
	//	printf("Sample 2 Result: %lld\n", sacRes2);
	//	printf("SAC Output: %lli\n", sacSum);
	//	printf("VDC: %i\n", VDC);
	//	printf("VMIN: %i\n", vMIN);
	//	printf("VMAX: %i\n", vMAX);
	//	printf("Vpk-pk: %i\n", pk_pk);

//////////////////////////////////////////////////////////////////////////////////////////
//							         code for SQRT									    //
//////////////////////////////////////////////////////////////////////////////////////////
	radicand = sacSum >> SAMP_BITS;
	UN = floor(radicand);
	SFACTOR = 0;
	count = 2;
	SN = 0;

	do {
		SFACTOR++;
		count <<= 1;
	} while(count < UN);

	SN = radicand / (count >> 1);
	SN_Q30 = (uint32_t) (SN * (1 << 30));
	gSQRTConfig.scaleFactor = SFACTOR;
	DL_MathACL_startSqrtOperation(MATHACL, &gSQRTConfig, SN_Q30);
	DL_MathACL_waitForOperation(MATHACL);

	sqrtRes_Q16 = DL_MathACL_getResultOne(MATHACL);
	//	sqrtRes1 = (int)(sqrtRes_Q16>> 16);
	//	sqrtRes2 = (int)(sqrtRes_Q16);
	//	combVal = (sqrtRes1 <<16) | sqrtRes2;
	//	SQRTRes = (float) combVal/(1<<16);
	printf("SQRT Output: 0x%x\n", sqrtRes_Q16);

//////////////////////////////////////////////////////////////////////////////////////////

	DL_MathACL_clearResults(MATHACL);

	dataOutput[0] =  vMIN;		// minimum voltage converted from ADC value to voltage
	dataOutput[1] =  vMAX; 		// maximum voltage converted from ADC value to voltage
	dataOutput[2] =  pk_pk;		// Pk-pk voltage from ADC value
	dataOutput[3] =  VDC;		// DC voltage form ADC value
	dataOutput[4] =  vRMS;    	// VRMS form ADC values * sqrt(2)

	k_sleep(K_MSEC(3000)); // just using for debug to keep output visible for 10 seconds

}

void test_8bit_xfer(const struct device *dev, struct spi_cs_control *cs)
{
	struct spi_config config;

	config.frequency = 100000;
	config.operation = SPI_OP_MODE_MASTER | SPI_WORD_SET(8);
	config.slave = 0;
	config.cs = *cs;

	int datacount = 3;
	// uint8_t buff[datacount] = { 0x11, 0x22, 0x33};
	// uint8_t rxdata[datacount];

	struct spi_buf tx_buf[1] = {
		{.buf = buff, .len = datacount},
	};
	struct spi_buf rx_buf[1] = {
		{.buf = rxdata, .len = datacount},
	};

	struct spi_buf_set tx_set = { .buffers = tx_buf, .count = 1 };
	struct spi_buf_set rx_set = { .buffers = rx_buf, .count = 1 };

	int ret = spi_transceive_cb(dev, &config, &tx_set, &rx_set, spi_callback, NULL);

	printf("8bit_partial; ret: %d\n", ret);
	printf(" tx (i)  : %02x %02x %02x\n",
	       buff[0], buff[1], buff[2]);

	while(transactionFlag == 0){
		k_usleep(20);
	}

	printf("8bit finished\n");
	printf(" rx (i)  : %02x %02x %02x\n",
	    	rxBuffer[0], rxBuffer[1], rxBuffer[2]);
}

void drdyEdge(const struct device *dev, struct gpio_callback *cb, uint32_t pins){
	printf("Drdy Edge GPIO Call\n");
	dataReady = true;
	test_8bit_xfer(dev, &cs_ctrl);//, spiData);  // get data from the ADC and send to buffer
}

int main(void)
{
//	const struct device *const dev = DEVICE_DT_GET(SPI_1_NODE);
	sampleCounter = NUM_SAMPLES; 	// set initial sample window count

	if (!device_is_ready(dev)) {
		printk("%s: device not ready.\n", dev->name);
		return 0;
	}

//	struct spi_cs_control cs_ctrl = (struct spi_cs_control){
//		.gpio = GPIO_DT_SPEC_GET(SPI_1_NODE, cs_gpios),
//		.delay = 0u,
//	};

	DL_MathACL_enablePower(MATHACL);

	// configure and set GPIO pin
	gpio_pin_configure_dt(&reset, GPIO_OUTPUT_INACTIVE);
	gpio_pin_configure_dt(&start, GPIO_ACTIVE_HIGH);
	gpio_pin_configure_dt(&drdy,  GPIO_ACTIVE_HIGH);
	gpio_pin_configure_dt(&en,    GPIO_ACTIVE_HIGH);
	gpio_pin_configure_dt(&done,  GPIO_ACTIVE_HIGH);

	DL_MathACL_clearResults(MATHACL);
	adcSetup();

	// set up callback for the DRDY pin of the adc
	gpio_init_callback(&drdy_cb_data, drdyEdge, BIT(drdy.pin));
	gpio_add_callback(drdy.port, &drdy_cb_data);

	setSTART(true);

	while (1) {
		// first set the operands to 0 to make sure the result is correct
		DL_MathACL_setOperandOne(MATHACL, 0);
		DL_MathACL_setOperandTwo(MATHACL, 0);

		//rnd = rand() % 4096 + 1;
		if (sampleCounter > 0) { 			// Have we collected all samples in window?
			if(dataReady){ 					// wait for data to be ready from the ADC
				dataReady = false;			// reset until callback indicates data is ready
				cSample = rxBuffer[0];		// !! need to see how to push rx data into the int16

				DL_MathACL_configOperation(MATHACL, &gSACConfig, cSample, 0);
				DL_MathACL_waitForOperation(MATHACL);

				sumSAMP += cSample; 		// add value to total sum for this window
				sampleCounter--;            // decrement the sample count

				if(cSample> vMAX){          // Set min and max values based on samples we have already taken
					vMAX = cSample;
				}else if(cSample<vMIN){
					vMIN = cSample;
				}
			} else{ //............		    //do nothing since data is not ready yet
				}
			} else{
				setSTART(false);			// now we have all samples, stop ADC sampling
				calculateResult();			// calculate results to be sent to display
				resetVars(); 				// Reset the variable values for next iteration
				gpio_pin_set_dt(&done, 1);  // indicate window is complete
				k_sleep(K_MSEC(10000));     // delay for a little while
				setSTART(true); 			// Set up ADC for next window of sampling
				gpio_pin_set_dt(&done, 0);  // reset the done pin for next window
			}
		}
	return 0;
}
