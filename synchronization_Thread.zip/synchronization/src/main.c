/* main.c - Synchronization demo */

/*
 * Copyright (c) 2012-2014 Wind River Systems, Inc.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include <zephyr/kernel.h>
#include <zephyr/sys/printk.h>
#include <zephyr/drivers/gpio.h>
#include <ti/devices/msp/msp.h>
#include <ti/driverlib/dl_common.h>
#include <zephyr/device.h>
#include <zephyr/devicetree.h>
#include <zephyr/sys/util.h>
#include <zephyr/sys/__assert.h>
#include <string.h>
/*
 * The synchronization demo has two threads that utilize semaphores and sleeping
 * to take turns printing a greeting message at a controlled rate. The demo
 * shows both the static and dynamic approaches for spawning a thread; a real
 * world application would likely use the static approach for both threads.
 */

#define PIN_THREADS (IS_ENABLED(CONFIG_SMP) && IS_ENABLED(CONFIG_SCHED_CPU_MASK))

#define ZEPHYR_USER_NODE DT_PATH(zephyr_user)
#define SPI_1_NODE	DT_NODELABEL(spi1)
#define LED0_NODE DT_NODELABEL(led0)

/* size of stack area used by each thread */
#define STACKSIZE 1024

/* scheduling priority used by each thread */
#define PRIORITY 7
bool gpio_state = true;
/* delay between greetings (in ms) */
#define SLEEPTIME 1000

void gpio_toggle(void){
	gpio_state = !gpio_state;
	printf("GPIO state: %s\n", gpio_state ? "ON" : "OFF");
	gpio_pin_set_dt(&start,gpio_state);
}

/* define semaphores */
K_SEM_DEFINE(thread_a_sem, 1, 1);	/* starts off "available" */
//K_SEM_DEFINE(thread_b_sem, 0, 1);	/* starts off "not available" */

/* thread_a is a dynamic thread that is spawned in main */
void thread_a_entry_point(void *dummy1, void *dummy2, void *dummy3)
{

	ARG_UNUSED(dummy1);
	ARG_UNUSED(dummy2);
	ARG_UNUSED(dummy3);

	while(1){
		gpio_toggle();
		k_msleep(SLEEPTIME);
	}


	/* invoke routine to ping-pong hello messages with thread_b */

}
K_THREAD_STACK_DEFINE(thread_a_stack_area, STACKSIZE);
static struct k_thread thread_a_data;

/* thread_b is a static thread spawned immediately */
//void thread_b_entry_point(void *dummy1, void *dummy2, void *dummy3)
//{
//	ARG_UNUSED(dummy1);
//	ARG_UNUSED(dummy2);
//	ARG_UNUSED(dummy3);
//
//	/* invoke routine to ping-pong hello messages with thread_a */
//	hello_loop(__func__, &thread_b_sem, &thread_a_sem);
//}
//K_THREAD_DEFINE(thread_b, STACKSIZE,
//				thread_b_entry_point, NULL, NULL, NULL,
//				PRIORITY, 0, 0);
//extern const k_tid_t thread_b;

int main(void)
{
	k_thread_create(&thread_a_data, thread_a_stack_area,
			K_THREAD_STACK_SIZEOF(thread_a_stack_area),
			thread_a_entry_point, NULL, NULL, NULL,
			PRIORITY, 0, K_FOREVER);
	k_thread_name_set(&thread_a_data, "thread_a");
	gpio_pin_configure_dt(&start, GPIO_OUTPUT_INACTIVE);
#if PIN_THREADS
	if (arch_num_cpus() > 1) {
		k_thread_cpu_pin(&thread_a_data, 0);

		/*
		 * Thread b is a static thread that is spawned immediately. This means that the
		 * following `k_thread_cpu_pin` call can fail with `-EINVAL` if the thread is
		 * actively running. Let's suspend the thread and resume it after the affinity mask
		 * is set.
		 */
//		k_thread_suspend(thread_b);
//		k_thread_cpu_pin(thread_b, 1);
//		k_thread_resume(thread_b);
	}
#endif

	k_thread_start(&thread_a_data);
	return 0;
}
